@extends('layouts.app')
@section('title') About :: @parent @endsection
@section('content')
    <div class="row">
        <div class="page-header">
            <h2>About Page</h2>
        </div>
    </div>
@endsection