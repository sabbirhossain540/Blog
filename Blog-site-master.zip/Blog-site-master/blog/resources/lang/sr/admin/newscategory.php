<?php

return [
    'newscategories' => 'Категорије новоти',


];