<?php

return [
    'photo' => 'Slike',
    'album' =>  'Album',
    'album_cover' => 'Naslovna slika',
    'slider' => 'Slider',
    'description' => 'Opis',
    'picture' => 'Slika',

];